import requests
import pandas as pd
import json
import re
import csv
from canvasapi import Canvas
import getpass
from helpers import createInstance, createCSV
import sys

# Get the course information to begin with

# from that table identify change and create
# CSV file 

# once csv file is confirmed move the accounts

# instantiate Canvas
# instantiate Account
# from Account get courses

FOLDER = "Subaccount Movement"
INPUT = "{}/input".format(FOLDER)
OUTPUT = "{}/output".format(FOLDER)

API_KEY = getpass.getpass("Enter token: ")
canvas = createInstance(API_URL, API_KEY)

def getAccount():
    """Prompt user for account id. Retrieves the account name from the account ID.
    
    Returns: 
        an Account object 
    """
    
    #prompt user for account id
    account_id = input("Please enter the account id you would like to apply this to \n")
    
    #retrieve account and account name 
    account = canvas.get_account(account_id)
    account_name = account.name
    print("You selected account: {}, {}".format(account_id, account_name))
    
    #return inputs
    return(account)

def getCourses(account):
    """Creates a dictionary of each course's properties and puts them into a data frame
    
    Args:
        account (account): the account or sub-account containing desired courses
        
    Returns: 
         a dataframe containing the courses in  account along with their properties
    """
    
    #get courses from account
    print("Getting courses from account.\n")
    courses = account.get_courses(per_page=50,
                                include=["term", "account_name", "account"])
    
    #create a dataframe populated with dictionaries of each course's fields
    all_courses = []
    for c in courses:
        course_dict = {"course_id": c.id,
                    "name": c.name,
                    "course_code": c.course_code,
                    "account_id": c.account_id,
                    "parent_account_id": c.account["parent_account_id"],
                    "root_account_id": c.account["root_account_id"],
                    "account_name": c.account["id"],
                    "term_name": c.term["name"],
                    "term_id": c.term["id"]
                    }
        #Q: is it necessary to put the dictionaries in a list before putting them in a dataframe. if so, why?
        all_courses.append(course_dict)    
    course_df = pd.DataFrame(all_courses)
    return(course_df)

#Tuples formatted as (subaccount name, subaccount #); specific courses will end up in these sub-accounts.
      
RED = ("RED", 588) #changed from 369 2020-05-20
LS = ("Learning Services", 456)
BMM = ("B+MM", 466)
BCOM = ("BCOM", 489)
DAP = ("DAP", 455)
PHD = ("PHD", 457)
COEC = ("COEC", 491)
COMR = ("COMR", 490)
MEL = ("MEL", 463)
MMOR = ("MMOR", 454)
MBAN = ("MBAN", 475) 
FTMBA = ("FTMBA", 486)
PMBA = ("PMBA", 478)
IMBA = ("IMBA", 482)
MMDD = ("MM DD", 469)
MM = ("MM", 472)
PARENT = ("Parent", 454)

#custom list of DAP BUSI courses, all else go to RED 
#last update 2020-05-24
DAP_COURSE_LIST = ["291", "293", "294", "295", "329", "335", "353", "354", "355", "370", "393", "450", "453", "455", "465", "493"]


def match_course(x):
    """Matches courses to their corresponding sub-accounts when the arguments match a known syntax pattern.
    """
    
    def regex_compare(regex_str, match_str, match=True):
        """Searches for a match between regex_string and match_string 
        
           Args:
                regex_str (string): the string to search for 
                match_str (string): the string to be searched 
                match (boolean): True if regex_str and match_str are known to match
           
           Returns:
                  A match object if a match is found, None otherwise.
        """
        if match == True:
            #compile --> creates a regular expression object which can e used for matching 
            #re.IGNORECASE --> perform a case-insensitive matching

            #match --> If zero or more characters at the beginning of string match regex_str 
            #search --> Scan through string looking for the first location where the regex_str produces a match.
            
            # CHANGE: in return statements, changed re.IGNORECASE to re.I
            return(re.compile(regex_str, re.I).match(match_str))
        else:
            return(re.compile(regex_str, re.I).search(match_str))

    def course_match_account(sub, course, sec):
        """Matches courses to their corresponding sub-accounts using regex pattern comparison
        
           Args (verify):
               sub (string): name of the sub-account
               course (string): name of the course
               sec (string): name of the course section
           
           Returns: 
                a tuple containing the subaccount name and ID that the course is sorted into
        """
        
        if (sub=="COEC" or sub=="COMM"):
            if regex_compare("[5|6][0-9][0-9][a-zA-Z]*", course):
                return(PHD)
            elif sub=="COEC":
                return(COEC)
            elif sub=="COMM":
                if regex_compare("MM[0-9]", sec):
                    return(MM)
                elif regex_compare("DD[0-9]", sec):
                    return(BMM)
                else:
                    return(BCOM)
            
        elif sub=="APPP":
            return(MEL)
                
        # if subject is BUSI, and section in DAP_COURSE_LIST, then DAP else RED
        elif sub=="BUSI":
            if course in DAP_COURSE_LIST:
                return(DAP)
            else:
                return(RED)
            
        # backup - RED uses section format 00X where DAP uses 10X etc
        # to be confirmed with Ops - and replace above DAP_COURSE_LIST
#         elif sub=="BUSI":
#             if regex_compare("00[0-9]", sec):
#                 return(RED)
#             else:
#                 return(DAP)
        
        #BA** courses
        elif regex_compare("BA[a-zA-Z]{0,2}", sub):
            # APSC courses seem to be very specific... 
            if ((regex_compare("BASC", sub) \
                 and regex_compare("550", course) \
                 and regex_compare("201", sec)) \
               or (regex_compare("580B", sec))):
                return(MEL)
        
            elif regex_compare("DD[0-9]", sec):
                return(MMDD)
            elif regex_compare("BA[0-9]", sec):
                return(MBAN)
            elif regex_compare("00[0-9]", sec):
                return(FTMBA)
            elif regex_compare("3[0-9]{2}", sec):
                return(PMBA)
            elif regex_compare("8[0-9]{2}", sec):
                return(IMBA)
            elif regex_compare("MM[0-9]", sec):
                return(MM)
        
        else:
            return(PARENT)
        
    def course_nomatch_account(x):
        """Sorts courses whose names do not match a known syntax pattern 
        (i.e. course_match == None) into proper subaccounts by using other identifiers
        
        Args: 
            x (string): course code (??)
        """
        if regex_compare(r"\b(learning( *)services|ls|sand( *)box|test)\b", x, False):
            return(LS)
        elif regex_compare(r"\bDAP\b", x, False):
            return(DAP)
        elif regex_compare(r"\b(B\+MM|BMM)\b", x, False):
            return(BMM)
        elif regex_compare(r"\bIMBA\b", x, False):
            return(IMBA)
        elif regex_compare(r"\bPMBA\b", x, False):
            return(PMBA)
        elif regex_compare(r"\bFTMBA\b", x, False):
            return(FTMBA)
        elif regex_compare(r"^MM\b", x, False):
            return(MM)
        elif regex_compare(r"\bMBAN\b", x, False):
            return(MBAN)
        else:
            return(PARENT)
        
    course_pattern = re.compile(r"((BA[a-zA-Z]{0,2})|COMM|COEC|BUSI|APPP)( *)([0-9]{3}[a-zA-Z]{0,1})( *)([0-9]{3}|(BA|MM|DD)[0-9])", flags=re.IGNORECASE)
    course_match = course_pattern.search(str(x))
    
    if course_match:
        course_str = course_match.group().split(" ", 3)
        out = course_match_account(*course_str)
        return(out)
        print("{}: {}".format(course_str, out))
    else:
        out = course_nomatch_account(x)
        return(out)
        print("{}: {}".format(x, out))



def updateCourseAccounts(course_df):
    
    """Creates a new dataframe of the courses once they have been moved to their new sub-accounts.
    
       Args:
           course_df(DataFrame): Data Frame containing courses in old sub-accounts
           
    """
    update_data = []

    #get properties of all course in the data frame
    for index, row in course_df.iterrows():
        course_id = str(row["course_id"])
        course_code = str(row["course_code"]).replace(".", " ")
        original_account = str(row["account_id"])
        course_name = str(row["name"])
        term_name = str(row["term_name"])
        term_id = str(row["term_id"])
     
    #try to match course to a sub-account by course code or by course name
        try:
            new_account, new_account_id = match_course(course_code)
            match_at = "course code"
        except:
            try:
                new_account, new_account_id = match_course(course_name)
                match_at = "course name"
            except:
                new_account, new_account_id = ("ERROR", "ERROR")
                match_at = "none"
        
        #create a new data frame with the updated account and account id.
        details = {"course_id": course_id,
                "course_code": course_code,
                "course_name": course_name,
                "term_name": term_name,
                "term_id": term_id,
                "original_account": original_account,
                "new_account": new_account,
                "new_account_id": new_account_id,
                "match_at": match_at}
        
        update_data.append(details)
        
    df = pd.DataFrame(update_data)
    print("Creating csv to check \n")
    
    #create CSV file 
    createCSV(df, "{}/Subaccount Movement To Be Confirmed.csv".format(OUTPUT))


def createSubaccountMovementCSV():
    
    """Creates a CSV file of each course and their properties post sub-account movement. 
       Prompts user to verify that the CSV file is correct.
    """
    print("Generating CSV for subaccount updating")
    account = getAccount()
    course_df = getCourses(account)
    course_df.head()
    updateCourseAccounts(course_df)
    print("Review the csv described above and move to {} with the name '{}/Subaccount Movement Confirmed.csv'".format(INPUT, INPUT))


def updateSteps():
    """Perform sub-account movement
    """
    
    #read subaccount movement csv and perform subaccount movement
    try:
        update_accounts = pd.read_csv("{}/Subaccount Movement Confirmed.csv".format(INPUT))

        print(update_accounts.head())
    except OSError as e:
        print(e)
        sys.exit(1)
    
    for index, row in update_accounts.iterrows():
        course_id = str(row["course_id"])
        new_account_id = str(row["new_account_id"])
        
        if str(row["new_account_id"]) == str(row["original_account"]):
            print ("Course (ID:" + str(course_id) + ") does not need to move - in the subaccount " + str(new_account_id) + "\n")
        
        else:
            
            r = requests.put(API_URL + "/api/v1/courses/" + str(course_id),
                                                headers= {"Authorization": "Bearer " + API_KEY},
                                                params = {"course[account_id]": int(new_account_id)})
           
            print ("Course (ID:" + str(course_id) + ") has been moved to the subaccount " + str(new_account_id)  + "\n")

    print("Complete Subaccount Movement")

def updateSubaccounts():
    """Prompt user to confrim they are ready for subaccount movement. 
       If yes, performs sub-account movement.
    """
    # user inout - are you sure 
    userConfirm = None
    
    #prompt user for confirmation to perform sub-account movements
    while userConfirm not in("y", "n"):
        userConfirm = input("Please confirm you checked the input and now want to move courses (CANNOT UNDO) (y/n)\n")
        if userConfirm == "y":  
            updateSteps()
        elif userConfirm == "n":
            print("Update the subaccount csv and try again.")
            sys.exit(1)

        else:
            print("Please indicate if you would like to update 'y' or 'n'")

    # get the csv
    # once confirmed, use new csv
    
